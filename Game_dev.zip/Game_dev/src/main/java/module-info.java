module com.margarito.game_dev {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.margarito.game_dev to javafx.fxml;
    exports com.margarito.game_dev;
}