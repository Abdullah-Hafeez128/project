package com.margarito.game_dev;

import javafx.animation.AnimationTimer;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;

public class GameController {

    @FXML
    private Pane gamePane;

    @FXML
    private ImageView carImageView;

    @FXML
    private ImageView environmentImageView;

    @FXML
    private ImageView environmentImageView2;
    @FXML
    private ImageView obstacleImageView;

    private double obstacleX = 1200; // Initial X position of the obstacle (off-screen to the right)
    private final double obstacleY = 650;

    @FXML
    private ImageView flagImageView;

    private double flagX = 1500; // Initial position of the flag (off-screen)
    private double flagY = 600; // Same Y-coordinate as the car

    @FXML
    private Button jumpButton;

    private boolean isJumping = false; // Track if the car is jumping
    private final double jumpHeight = 150; // Height of the jump
    private final double jumpSpeed = 2.0; // Speed of the jump
    private double initialCarY; // To store the car's original Y position



    @FXML
    private Button accelerateButton;

    @FXML
    private Button brakeButton;

    private double backgroundPositionX = 0;
    private double speed = 2.0; // Background scroll speed
    private boolean isMoving = false;

    /**
     * Sets the selected car image based on the user's choice.
     */
    public void setSelectedCar(String carType) {
        String imagePath = switch (carType) {
            case "Sports Car" -> "file:C:/Users/Margarito/Desktop/Game_dev/src/main/resources/com/margarito/Game_dev/images/racingCar.png";
            case "Muscle Car" -> "file:C:/Users/Margarito/Desktop/Game_dev/src/main/resources/com/margarito/Game_dev/images/musclecar.jpg";
            case "Electric Car" -> "file:C:/Users/Margarito/Desktop/Game_dev/src/main/resources/com/margarito/Game_dev/images/electricCar.jpg";
            case "Classic Car" -> "file:C:/Users/Margarito/Desktop/Game_dev/src/main/resources/com/margarito/Game_dev/images/classic.jpg";
            case "Truck" -> "file:C:/Users/Margarito/Desktop/Game_dev/src/main/resources/com/margarito/Game_dev/images/bluetruck.jpg";
            case "Convertible Car" -> "file:C:/Users/Margarito/Desktop/Game_dev/src/main/resources/com/margarito/Game_dev/images/convertablecar.jpg";
            case "Hybrid Car" -> "file:C:/Users/Margarito/Desktop/Game_dev/src/main/resources/com/margarito/Game_dev/images/hybridcar.jpg";
            case "Mini Van" -> "file:C:/Users/Margarito/Desktop/Game_dev/src/main/resources/com/margarito/Game_dev/images/minivan.jpg";
            case "SUV" -> "file:C:/Users/Margarito/Desktop/Game_dev/src/main/resources/com/margarito/Game_dev/images/suv.jpg";
            default -> null;
        };

        if (imagePath != null) {
            carImageView.setImage(new Image(imagePath));
        }
    }

    /**
     * Sets the environment background based on the user's choice.
     */
    public void setSelectedEnvironment(String environment) {
        String imagePath = switch (environment) {
            case "Night" -> "file:C:/Users/Margarito/Desktop/Game_dev/src/main/resources/com/margarito/Game_dev/images/night.png";
            case "Autumn" -> "file:C:/Users/Margarito/Desktop/Game_dev/src/main/resources/com/margarito/Game_dev/images/autumn.png";
            case "Beach" -> "file:C:/Users/Margarito/Desktop/Game_dev/src/main/resources/com/margarito/Game_dev/images/beach.jpg";
            case "Mountain" -> "file:C:/Users/Margarito/Desktop/Game_dev/src/main/resources/com/margarito/Game_dev/images/mountain.jpg";
            case "Forest" -> "file:C:/Users/Margarito/Desktop/Game_dev/src/main/resources/com/margarito/Game_dev/images/forest.jpg";
            case "Rainy" -> "file:C:/Users/Margarito/Desktop/Game_dev/src/main/resources/com/margarito/Game_dev/images/rainy.gif";
            case "Subway" -> "file:C:/Users/Margarito/Desktop/Game_dev/src/main/resources/com/margarito/Game_dev/images/subway.jpg";
            case "Snowy" -> "file:C:/Users/Margarito/Desktop/Game_dev/src/main/resources/com/margarito/Game_dev/images/snowy.jpg";
            case "Desert" -> "file:C:/Users/Margarito/Desktop/Game_dev/src/main/resources/com/margarito/Game_dev/images/desert.avif";
            case "City" -> "file:C:/Users/Margarito/Desktop/Game_dev/src/main/resources/com/margarito/Game_dev/images/city.jpg";
            default -> null;
        };

        if (imagePath != null) {
            Image environmentImage = new Image(imagePath);
            environmentImageView.setImage(environmentImage);
            environmentImageView2.setImage(environmentImage);

            // Make both background images fit the pane
            environmentImageView.fitWidthProperty().bind(gamePane.widthProperty());
            environmentImageView.fitHeightProperty().bind(gamePane.heightProperty());
            environmentImageView.setPreserveRatio(false);

            environmentImageView2.fitWidthProperty().bind(gamePane.widthProperty());
            environmentImageView2.fitHeightProperty().bind(gamePane.heightProperty());
            environmentImageView2.setPreserveRatio(false);
        }
    }

    /**
     * Set the position of the car on the gamePane.
     *
     * @param x The X coordinate for the car.
     * @param y The Y coordinate for the car.
     */
    public void setCarPosition(double x, double y) {
        carImageView.setLayoutX(x);
        carImageView.setLayoutY(y);
    }

    private void restartGame() {
        // Reset background positions
        backgroundPositionX = 0;
        environmentImageView.setLayoutX(backgroundPositionX);
        environmentImageView2.setLayoutX(backgroundPositionX + environmentImageView.getImage().getWidth());

        // Reset obstacle position
        obstacleX = 1200; // Place the obstacle off-screen to the right
        obstacleImageView.setLayoutX(obstacleX);
        flagX = 1500;
        flagImageView.setLayoutX(flagX);

        // Reset car position
        setCarPosition(100, 650); // Initial position of the car
        carImageView.setLayoutY(initialCarY);

        // Restart movement
        isMoving = false; // Optional: Start game paused, user must press 'Accelerate'
    }

    private void youWin() {
        // Stop the game
        isMoving = false;

        // Display the win message
        javafx.scene.text.Text winText = new javafx.scene.text.Text("YOU WIN!");
        winText.setStyle("-fx-font-size: 48px; -fx-fill: green; -fx-font-weight: bold;");
        winText.setLayoutX(gamePane.getWidth() / 2 - 100); // Center the text
        winText.setLayoutY(gamePane.getHeight() / 2); // Center the text
        gamePane.getChildren().add(winText);
    }


    /**
     * Initialize the game controller with event handlers and the game loop.
     */
    @FXML
    public void initialize() {
        setCarPosition(100, 650);

        // Add obstacle programmatically
        obstacleImageView = new ImageView(new Image("file:C:/Users/Margarito/Desktop/Game_dev/src/main/resources/com/margarito/Game_dev/images/box.png"));
        obstacleImageView.setLayoutX(obstacleX);
        obstacleImageView.setLayoutY(obstacleY);
        obstacleImageView.setFitWidth(50); // Set obstacle size
        obstacleImageView.setFitHeight(50);
        gamePane.getChildren().add(obstacleImageView);

        //initialize flag
        flagImageView = new ImageView(new Image("file:C:/Users/Margarito/Desktop/Game_dev/src/main/resources/com/margarito/Game_dev/images/flag.png"));
        flagImageView.setLayoutX(flagX);
        flagImageView.setLayoutY(flagY);
        flagImageView.setFitWidth(75);
        flagImageView.setFitHeight(100);
        gamePane.getChildren().add(flagImageView);


        // Start and stop movement with buttons
        accelerateButton.setOnAction(event -> isMoving = true);
        brakeButton.setOnAction(event -> isMoving = false);

        initialCarY = carImageView.getLayoutY(); // Store the original Y position of the car

        jumpButton.setOnAction(event -> {
            if (!isJumping) {
                isJumping = true;
            }
        });


        // Game loop
        AnimationTimer timer = new AnimationTimer() {
            @Override
            public void handle(long now) {
                if (isMoving) {
                    // Move backgrounds for parallax scrolling
                    backgroundPositionX -= speed;
                    obstacleX -= speed;
                    flagX -= speed;
                    flagImageView.setLayoutX(flagX);

                    environmentImageView.setLayoutX(backgroundPositionX);
                    environmentImageView2.setLayoutX(backgroundPositionX + environmentImageView.getImage().getWidth());

                    // Reset positions for seamless looping
                    if (backgroundPositionX <= -environmentImageView.getImage().getWidth()) {
                        backgroundPositionX = 0;
                    }

                    // Reset obstacle position if it moves off-screen
                    if (obstacleX < -50) {
                        obstacleX = 1200; // Reset to the right side
                    }
                    obstacleImageView.setLayoutX(obstacleX);

                    if (carImageView.getBoundsInParent().intersects(obstacleImageView.getBoundsInParent())) {
                        restartGame(); // Stop movement on collision
                    }

                    // Reset flag when it moves off-screen
                    if (flagX <= -flagImageView.getFitWidth()) {
                        flagX = 1500; // Restart flag position
                    }

                    // Handle jump logic
                    if (isJumping) {
                        if (carImageView.getLayoutY() > initialCarY - jumpHeight) {
                            carImageView.setLayoutY(carImageView.getLayoutY() - jumpSpeed); // Move up
                        } else {
                            isJumping = false; // Stop upward movement
                        }
                    } else if (carImageView.getLayoutY() < initialCarY) {
                        carImageView.setLayoutY(carImageView.getLayoutY() + jumpSpeed); // Move down
                    }

                    // Check for collision
                    if (!isJumping && carImageView.getBoundsInParent().intersects(obstacleImageView.getBoundsInParent())) {
                        restartGame(); // Restart game on collision
                    }

                    // Check if car reaches the flag
                    if (carImageView.getBoundsInParent().intersects(flagImageView.getBoundsInParent())) {
                        youWin();
                    }

                }
            }
        };
        timer.start();
    }
}
