package com.margarito.game_dev;

import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.fxml.FXMLLoader;

public class MainController {

    @FXML
    private ComboBox<String> carSelector;

    @FXML
    private ComboBox<String> environmentSelector;

    @FXML
    private Button startRaceButton;

    @FXML
    public void initialize() {
        // Populate ComboBoxes
        carSelector.getItems().addAll("Sports Car", "Muscle Car", "Electric Car", "Truck", "Classic", "Convertable Car", "Hybrid Car", "Mini Van", "SUV");
        environmentSelector.getItems().addAll("Night", "Autumn", "Forest", "Beach", "Subway", "Snowy", "Desert", "Mountain", "City", "Rainy");
    }

    @FXML
    public void onStartRace() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/margarito/game_dev/game_scene.fxml"));
            Scene gameScene = new Scene(loader.load());
            GameController controller = loader.getController();

            // Pass selected values to the game scene
            controller.setSelectedCar(carSelector.getValue());
            controller.setSelectedEnvironment(environmentSelector.getValue());

            // Switch scene
            Stage stage = (Stage) startRaceButton.getScene().getWindow();
            stage.setScene(gameScene);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}